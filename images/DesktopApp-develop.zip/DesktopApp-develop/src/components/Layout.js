import React, { useEffect, useState, useRef } from "react";
import { BrowserRouter as Router, useLocation } from "react-router-dom";

// css
import "../assets/css/Layout.css";

// // ICONS
import homeIcon from "../assets/img/icons/Vectorhome.svg";
import contactIcon from "../assets/img/icons/internet 1-contact.svg";
import salesIcon from "../assets/img/icons/sales 1.svg";
import produceIcon from "../assets/img/icons/Vector-produce.svg";
import inventoryIcon from "../assets/img/icons/inventory 1.svg";
import financeIcon from "../assets/img/icons/accounting 1.svg";
import truckIcon from "../assets/img/icons/truck 1.svg";
import reportsIcon from "../assets/img/icons/report 1.svg";
import productionIcon from "../assets/img/icons/manufacture 2.svg";
import supportIcon from "../assets/img/icons/Vector-support.svg";
import storeIcon from "../assets/img/icons/clarity_store-solid.svg";

// components

import FishHatcheryWrapper from "./ProductionFishHatchery/FishHatcheryWrapper";
import Wallet from "./Wallet/Wallet";

import Sidebar from "./Sidebar";
import Search from "./Search";
import PondRegistration from "./Pond List/PondRegistration";
import GroupWrapper from "./ExtensionOfficer/GroupWrapper";
import HarvestCollectionWrapper from "./HarvestCollectionRecording/HarvestCollectionWrapper";
import RecordFeeding from "./RecordFeeding/RecordFeeding";
import RegularFeedWrapper from "./Feed/RegularFeedWrapper";
import Booking from "./Booking/Booking";
import GroupCollectionPayment from "./GroupCollectionPayment/GroupCollectionPayment";
import OutboundWrapper from "./Outbound/OutboundWrapper";

import Transfer from "./Transfer/Transfer";

import CashAndBankWrapper from "./CashAndBank/CashAndBankWrapper";
import Training from "./Training/Training";

import Products from "./Products/Products";
import CRMDashboard from "./CRMDashboard/CRMDashboard"
import FinanceDashboard from "./FinanceDashboard/FinanceDashboard"



const routes = [
  {
    path: "/",
    exact: true,
    main: () => <Dashboard />,
    icon: homeIcon,
  },
  {
    path: "/contact",
    main: () => <p>contact works</p>,
    icon: contactIcon,
  },
  {
    path: "/sales",
    main: () => <SalesOrder />,
    icon: salesIcon,
  },
  {
    path: "/ponds",
    main: () => <PondRegistration />,
    icon: salesIcon,
  },
  {
    path: "/crm-dashboard",
    main: () => <CRMDashboard /> ,
    icon: salesIcon,
  },
  {
    path: "/finance-dashboard",
    main: () => <FinanceDashboard /> ,
    icon: salesIcon,
  },
  {
    path: "/hatchery",
    main: () => <FishHatcheryWrapper />,
    icon: salesIcon,
  },
  {
    path: "/feeds",
    main: () => <RegularFeedWrapper />,
    icon: salesIcon,
  },
  {
    path: "/produce",
    exact: true,
    main: () => <p>produce works</p>,
    icon: produceIcon,
  },
  {
    path: "/inventory",
    main: () => <p>inventory works</p>,
    icon: inventoryIcon,
  },
  {
    path: "/finance",
    main: () => <p>finance works</p>,
    icon: financeIcon,
  },
  {
    path: "/wallet",
    main: () => <Wallet />,
    icon: financeIcon,
  },
  {
    path: "/transfer",
    main: () => <Transfer />,
    icon: reportsIcon,
  },
  {
    path: "/expenses",
    main: () => <Expenses />,
    icon: financeIcon,
  },
  {
    path: "/cashandbank",
    main: () => <CashAndBankWrapper />,
    icon: inventoryIcon,
  },
  {
    path: "/harvest",
    main: () => <HarvestCollectionWrapper />,
    icon: inventoryIcon,
  },
  {
    path: "/reports",
    main: () => <p>Reports works</p>,
    icon: reportsIcon,
  },
  {
    path: "/training",
    main: () => <Training />,
    icon: truckIcon,
  },
  {
    path: "/logistics",
    main: () => <p>works</p>,
    icon: truckIcon,
  },
  {
    path: "/productions",
    main: () => <p>Productions</p>,
    icon: produceIcon,
  },

  {
    path: "/extension-officer",
    main: () => <GroupWrapper />,
    icon: productionIcon,
  },


  {
    path: "/products",
    main: () => <Products/>,
    icon: produceIcon,
  },


  {
    path: "/record",
    main: () => <RecordFeeding />,
    icon: productionIcon,
  },

  {
    path: "/groups",
    main: () => <GroupProfiling />,
    icon: productionIcon,
  },
  {
    path: "/purchase-bill",
    main: () => <PurchaseBillWrapper />,
    icon: supportIcon,
  },

  {
    path: "/outbound",
    main: () => <OutboundWrapper />,
    icon: supportIcon,
  },

  {
    path: "/store",
    main: () => <p>store works</p>,
    icon: storeIcon,
  },
  {

    path: "/settings",
    main: () => <SettingsWrapper />,

    path: "/booking",
    main: () => <Booking />,
    icon: storeIcon,
  },
  {
    path: "/groupcollectionpayment",
    main: () => <GroupCollectionPayment />,

    icon: storeIcon,
  },
];

const Layout = ({ children }) => {
  const main = useRef(null);

  let location = useLocation();

  const [sideOpen, setSideOpen] = useState(true);

  useEffect(() => {
    sideOpen
      ? (main.current.style.marginLeft = "254px")
      : (main.current.style.marginLeft = "17px");
  }, [sideOpen]);

  return (
    <React.Fragment>
      <div className="container-fluid p-0">
        <Sidebar
          isOpen={sideOpen}
          side={(bool) => setSideOpen(bool)}
          links={routes}
        />

        <main style={{ transition: "0.5s" }} ref={main} className="px-4">
          {location.pathname !== "/" && <Search />}
          {children}
        </main>
      </div>
    </React.Fragment>
  );
};
export default Layout;
