import React from "react";

const Booking = () => <h1></h1>;

export default Booking;
