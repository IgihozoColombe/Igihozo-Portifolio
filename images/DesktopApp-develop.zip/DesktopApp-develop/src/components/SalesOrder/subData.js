export  const subData = [
    {
        id:233,
        item:'Blue Marlin',
        Qty: 200,
        price: 20000,
        Units: 200,
        Amount: 4
    },

    {
        id:234,
        item:'Blue Marlin',
        Qty: 350,
        price: 10,
        Units: 350,
        Amount: 4
    },
    {
        id:235,
        item:'Blue Marlin',
        Qty: 450,
        price: 8,
        Units: 450,
        Amount: 4
    },
    {
        id:225,
        item:'Hogfish',
        Qty: 200,
        price: 10,
        Units: 200,
        Amount: 2
    },
    {
        id:236,
        item:'Hogfish',
        Qty: 500,
        price: 7,
        Units: 500,
        Amount: 3
    }
];