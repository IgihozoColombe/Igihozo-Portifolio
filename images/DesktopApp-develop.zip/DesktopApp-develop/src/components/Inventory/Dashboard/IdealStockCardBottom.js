import React from "react";

export default function IdealStockBottom(){
    return(
        <div className="card ideal-bottom-card d-flex justify-content-around">
            <h5 className="font-weight-bold">Less than the ideal Stock</h5>
        </div>
    )
}